/*
 * max30100.h
 *
 *  Created on: May 10, 2025
 *      Author: melikeozen
 */

#ifndef INC_MAX30100_H_
#define INC_MAX30100_H_


#include "main.h"
#include <math.h>
#include <stdio.h>
#include <string.h>
#include <stdlib.h>

extern I2C_HandleTypeDef hi2c1;
#define BUFFER_SIZE 100
#define MAX30100_ADDR         (0x57 << 1)
#define REG_MODE_CONFIG       0x06
#define REG_SPO2_CONFIG       0x07
#define REG_LED_CONFIG        0x09
#define REG_FIFO_DATA         0x05
#define REG_FIFO_WR_PTR       0x02
#define REG_FIFO_RD_PTR       0x04
#define REG_FIFO_OVF_COUNTER  0x03

void MAX30100_Init(void);
void MAX30100_Read_FIFO(volatile uint16_t *ir, volatile uint16_t *red);
uint8_t detect_peak(uint16_t *data, uint8_t i, uint16_t dc_value);
float calculate_bpm(uint32_t *last_time, uint32_t current_time);
float calculate_spo2(uint16_t *ir,uint16_t *red);

#endif /* INC_MAX30100_H_ */
