/*
 * max30100.c
 *
 *  Created on: May 10, 2025
 *      Author: melikeozen
 */
#include "max30100.h"
/* MAX30100 start */
void MAX30100_Init(void)
{
    uint8_t zero = 0x00;

    // FIFO yazma, okuma ve taşma sayacı sıfırlama
    HAL_I2C_Mem_Write(&hi2c1, MAX30100_ADDR, REG_FIFO_WR_PTR, 1, &zero, 1, HAL_MAX_DELAY);
    HAL_I2C_Mem_Write(&hi2c1, MAX30100_ADDR, REG_FIFO_RD_PTR, 1, &zero, 1, HAL_MAX_DELAY);
    HAL_I2C_Mem_Write(&hi2c1, MAX30100_ADDR, REG_FIFO_OVF_COUNTER, 1, &zero, 1, HAL_MAX_DELAY);

    // Mod konfigürasyonu: SpO2 mode
    uint8_t mode = 0x03;
    HAL_I2C_Mem_Write(&hi2c1, MAX30100_ADDR, REG_MODE_CONFIG, 1, &mode, 1, HAL_MAX_DELAY);

    // SpO2 konfigürasyonu: 100Hz örnekleme, 1600us pulse width
    uint8_t spo2_cfg = 0x27;
    HAL_I2C_Mem_Write(&hi2c1, MAX30100_ADDR, REG_SPO2_CONFIG, 1, &spo2_cfg, 1, HAL_MAX_DELAY);

    // LED konfigürasyonu: IR = 24mA, RED = 7mA
    uint8_t led_cfg = 0xB8;
    HAL_I2C_Mem_Write(&hi2c1, MAX30100_ADDR, REG_LED_CONFIG, 1, &led_cfg, 1, HAL_MAX_DELAY);
}

/* Read IR and RED data from FIFO */
void MAX30100_Read_FIFO(volatile uint16_t *ir, volatile uint16_t *red)
{
    uint8_t data[4];

    HAL_I2C_Mem_Read(&hi2c1, MAX30100_ADDR, REG_FIFO_DATA, 1, data, 4, HAL_MAX_DELAY);

    *ir  = ((uint16_t)data[0] << 8) | data[1];
    *red = ((uint16_t)data[2] << 8) | data[3];
}

/* Peak Detection */
uint8_t detect_peak(uint16_t *data, uint8_t i, uint16_t dc_value)
{
    if (i < 2 || i >= BUFFER_SIZE - 2) return 0;

    static uint32_t last_peak_time = 0;
    uint32_t now = HAL_GetTick();
    const uint32_t min_peak_distance = 300;

    int16_t val = data[i] - dc_value;
    int16_t dynamic_threshold = dc_value * 0.008;
    if (val > (data[i - 1] - dc_value) &&
        val > (data[i - 2] - dc_value) &&
        val > (data[i + 1] - dc_value) &&
        val > (data[i + 2] - dc_value) &&
        val > dynamic_threshold)
    {
        if ((now - last_peak_time) >= min_peak_distance)
        {
            last_peak_time = now;
            return 1;
        }
    }
    return 0;
}

/* Calculating BBPM */
float calculate_bpm(uint32_t *last_time, uint32_t current_time)
{
    uint32_t dt = current_time - *last_time;
    if (dt < 300 ) return -1;
    *last_time = current_time;
    return 60000.0f / dt;
}

/* Calculating SPO2 */
float calculate_spo2(uint16_t *ir, uint16_t *red)
{
    uint32_t ir_dc = 0, red_dc = 0;
    int32_t ir_diff = 0, red_diff = 0;
    float ir_ac_rms = 0, red_ac_rms = 0;

    for (uint8_t i = 0; i < BUFFER_SIZE; i++)
    {
        ir_dc += ir[i];
        red_dc += red[i];
    }

    ir_dc /= BUFFER_SIZE;
    red_dc /= BUFFER_SIZE;

    for (uint8_t i = 0; i < BUFFER_SIZE; i++)
    {
        ir_diff = (int32_t)ir[i] - ir_dc;
        red_diff = (int32_t)red[i] - red_dc;

        ir_ac_rms += ir_diff * ir_diff;
        red_ac_rms += red_diff * red_diff;
    }

    ir_ac_rms = sqrtf(ir_ac_rms / BUFFER_SIZE);
    red_ac_rms = sqrtf(red_ac_rms / BUFFER_SIZE);

    float ratio = (red_ac_rms / red_dc) / (ir_ac_rms / ir_dc);
    float spo2 = 110.0f - 25.0f * ratio;

    if (spo2 > 100) spo2 = 100;
    if (spo2 < 60)  spo2 = 60;

    return spo2;
}
